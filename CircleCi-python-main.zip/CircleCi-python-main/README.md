## Python - CircleCI

### Run the code
```
python main.py
```

### Test the code
```
python tests.py
```